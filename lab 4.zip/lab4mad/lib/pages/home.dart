// ============================================================
//  HemaVision - Lab 4: Introduction to Widgets
//  FILE: lib/pages/home.dart
//  WIDGETS USED: Scaffold, AppBar, SafeArea, SingleChildScrollView,
//                Padding, Column, Divider, Text
// ============================================================

import 'package:flutter/material.dart';
import '../widgets/user_profile.dart';
import '../widgets/cbc_metrics.dart';
import '../widgets/ai_result_card.dart';
import '../widgets/recent_reports.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    // ✅ WIDGET: Scaffold
    // Provides the basic Material Design layout structure.
    // Holds AppBar and body together.
    return Scaffold(

      // ✅ WIDGET: AppBar
      // Displays the top navigation bar with the app title.
      appBar: AppBar(
        backgroundColor: Color(0xFFC0392B),
        title: Text(
          'HemaVision',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
        ),
      ),

      // ✅ WIDGET: SafeArea
      // Prevents content from going under notches, status bar, or nav bar.
      body: SafeArea(

        // ✅ WIDGET: SingleChildScrollView
        // Makes the entire body scrollable vertically.
        child: SingleChildScrollView(

          // ✅ WIDGET: Padding
          // Adds 16px space on all sides of the content.
          child: Padding(
            padding: EdgeInsets.all(16.0),

            // ✅ WIDGET: Column
            // Stacks all sections vertically: profile → metrics → result → reports.
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[

                // Section: User Profile
                UserProfile(),

                Padding(padding: EdgeInsets.all(10.0)),

                // ✅ WIDGET: Divider
                // Horizontal separator line between sections.
                Divider(color: Colors.grey, thickness: 1),

                Padding(padding: EdgeInsets.all(6.0)),

                // Section: CBC Metrics
                Text(
                  'CBC Analysis Summary',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF2C3E50),
                  ),
                ),

                Padding(padding: EdgeInsets.all(8.0)),

                CbcMetrics(),

                Padding(padding: EdgeInsets.all(10.0)),
                Divider(color: Colors.grey, thickness: 1),
                Padding(padding: EdgeInsets.all(6.0)),

                // Section: AI Result
                Text(
                  'AI Detection Result',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF2C3E50),
                  ),
                ),

                Padding(padding: EdgeInsets.all(8.0)),

                AiResultCard(),

                Padding(padding: EdgeInsets.all(10.0)),
                Divider(color: Colors.grey, thickness: 1),
                Padding(padding: EdgeInsets.all(6.0)),

                // Section: Recent Reports
                Text(
                  'Recent Reports',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF2C3E50),
                  ),
                ),

                Padding(padding: EdgeInsets.all(8.0)),

                RecentReports(),

                Padding(padding: EdgeInsets.all(16.0)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}