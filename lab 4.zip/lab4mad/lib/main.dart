import 'package:flutter/material.dart';
import 'pages/home.dart';

void main() => runApp(HemaVisionApp());

class HemaVisionApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'HemaVision',
      theme: ThemeData(primarySwatch: Colors.red),
      home: Home(),
    );
  }
}