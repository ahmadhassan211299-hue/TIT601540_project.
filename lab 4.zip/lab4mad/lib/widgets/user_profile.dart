import 'package:flutter/material.dart';

class UserProfile extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        Stack(
          children: <Widget>[
            CircleAvatar(
              radius: 36,
              backgroundColor: Color(0xFFC0392B),
              child: Text(
                'AH',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.only(top: 52, left: 52),
              width: 14,
              height: 14,
              decoration: BoxDecoration(
                color: Colors.green,
                shape: BoxShape.circle,
              ),
            ),
          ],
        ),

        // ✅ WIDGET: Padding
        // Adds horizontal spacing between the avatar and the text column.
        Padding(padding: EdgeInsets.all(12.0)),

        // ✅ WIDGET: Expanded
        // Makes the text column fill all remaining horizontal space in the Row.
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[

              // ✅ WIDGET: Text
              // Displays the patient's name in bold.
              Text(
                'Ahmad',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF2C3E50),
                ),
              ),

              Text(
                'Patient ID: HV-2024-001',
                style: TextStyle(fontSize: 13, color: Colors.grey),
              ),

              Text(
                'Last Report: 12 May 2025',
                style: TextStyle(fontSize: 13, color: Colors.grey),
              ),
            ],
          ),
        ),
      ],
    );
  }
}