import 'package:flutter/material.dart';
class CbcMetrics extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Row(
          children: <Widget>[
            Expanded(
              child: _buildMetricCard(
                label: 'WBC',
                value: '12.4 K/µL',
                status: '↑ High',
                borderColor: Color(0xFFC0392B),
                bgColor: Color(0xFFFDEDED),
                valueColor: Color(0xFFC0392B),
                statusColor: Colors.orange,
              ),
            ),
            Padding(padding: EdgeInsets.all(6.0)),
            Expanded(
              child: _buildMetricCard(
                label: 'RBC',
                value: '4.2 M/µL',
                status: '✓ Normal',
                borderColor: Color(0xFF2980B9),
                bgColor: Color(0xFFEBF5FB),
                valueColor: Color(0xFF2980B9),
                statusColor: Colors.green,
              ),
            ),
          ],
        ),

        Padding(padding: EdgeInsets.all(8.0)),
        Row(
          children: <Widget>[
            Expanded(
              child: _buildMetricCard(
                label: 'Hemoglobin',
                value: '10.1 g/dL',
                status: '↓ Low',
                borderColor: Colors.grey,
                bgColor: Color(0xFFF9F9F9),
                valueColor: Colors.black87,
                statusColor: Colors.red,
              ),
            ),

            Padding(padding: EdgeInsets.all(6.0)),

            Expanded(
              child: _buildMetricCard(
                label: 'Platelets',
                value: '180 K/µL',
                status: '✓ Normal',
                borderColor: Colors.green,
                bgColor: Color(0xFFEAF7EA),
                valueColor: Colors.green,
                statusColor: Colors.green,
              ),
            ),
          ],
        ),
      ],
    );
  }
  Widget _buildMetricCard({
    required String label,
    required String value,
    required String status,
    required Color borderColor,
    required Color bgColor,
    required Color valueColor,
    required Color statusColor,
  }) {
    return Container(
      height: 90,
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: borderColor, width: 1),
      ),
      child: Padding(
        padding: EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[

            // ✅ WIDGET: Text — metric label (e.g. WBC, RBC)
            Text(label, style: TextStyle(fontSize: 13, color: Colors.grey)),

            // ✅ WIDGET: Text — metric value (e.g. 12.4 K/µL)
            Text(
              value,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: valueColor,
              ),
            ),
            Text(status, style: TextStyle(fontSize: 12, color: statusColor)),
          ],
        ),
      ),
    );
  }
}