import 'package:flutter/material.dart';

class RecentReports extends StatelessWidget {
  final List<Map<String, String>> reports = [
    {
      'title': 'Report #003',
      'date': '12 May 2025',
      'result': 'ALL - High Risk',
    },
    {
      'title': 'Report #002',
      'date': '01 Apr 2025',
      'result': 'AML - Medium Risk',
    },
    {
      'title': 'Report #001',
      'date': '15 Feb 2025',
      'result': 'Normal - No Cancer',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[

        _buildReportRow(reports[0]),
        Divider(),

        _buildReportRow(reports[1]),

        Divider(),

        _buildReportRow(reports[2]),
      ],
    );
  }
  Widget _buildReportRow(Map<String, String> report) {
    return Row(
      children: <Widget>[
        CircleAvatar(
          radius: 22,
          backgroundColor: Color(0xFFFDEDED),
          child: Text(
            'R',
            style: TextStyle(
              color: Color(0xFFC0392B),
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
        ),
        Padding(padding: EdgeInsets.all(8.0)),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                report['title']!,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                  color: Color(0xFF2C3E50),
                ),
              ),
              Text(
                report['date']!,
                style: TextStyle(color: Colors.grey, fontSize: 12),
              ),
              Text(
                report['result']!,
                style: TextStyle(color: Color(0xFFC0392B), fontSize: 12),
              ),
            ],
          ),
        ),
      ],
    );
  }
}