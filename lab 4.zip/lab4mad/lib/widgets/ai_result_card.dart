import 'package:flutter/material.dart';

class AiResultCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        Container(
          width: double.infinity,
          height: 120,
          decoration: BoxDecoration(
            color: Color(0xFFC0392B),
            borderRadius: BorderRadius.circular(16),
          ),
        ),
        Container(
          width: 100,
          height: 100,
          margin: EdgeInsets.only(left: 260, top: 10),
          decoration: BoxDecoration(
            color: Colors.white12,
            shape: BoxShape.circle,
          ),
        ),
        Padding(
          padding: EdgeInsets.all(20.0),

          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                'Acute Lymphocytic Leukemia',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),

              Padding(padding: EdgeInsets.all(4.0)),
              Text(
                'Risk Level: High   |   Stage: II',
                style: TextStyle(color: Colors.white70, fontSize: 13),
              ),

              Padding(padding: EdgeInsets.all(4.0)),
              Text(
                'Confidence: 91.4%',
                style: TextStyle(color: Colors.white, fontSize: 13),
              ),
            ],
          ),
        ),
      ],
    );
  }
}