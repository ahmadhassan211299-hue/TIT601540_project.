package com.example.lab4mad

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
